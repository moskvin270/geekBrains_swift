import Foundation

/*
 1. Описать несколько структур – любой легковой автомобиль SportCar и любой грузовик TrunkCar.
 2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.
 3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.
 4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.
 5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.
 6. Вывести значения свойств экземпляров в консоль.
 */

enum Engine {
    case start
    case off
}

enum Window {
    case open
    case close
}

enum Trunk {
    case load
    case unLoad
}

enum FullTrunk{
    case volume(м3: Int)
}

struct Auto {
    var brand: String = "Марка авто"                     // марка авто
    var yearOfIssue: Int                                 // год выпуска
    var trunkVolume: Int                                 // объем багажника
    var ignition: Engine                                 // зажигане
    var openWindow: Bool                                 // открыты ли окна
    var fullTrunk: Bool                                  // заполнение багажника


    mutating func settingIgnition (action: Engine) {
        switch action {
        case .start:
            print(action)
        case .off:
            print(action)
        }
    }
}


let sportCar = Auto(brand: "Audi", yearOfIssue: 2015, trunkVolume: 2, ignition: .off, openWindow: false, fullTrunk: false)
let cargoCar = Auto(brand: "Man", yearOfIssue: 2000, trunkVolume: 20, ignition: .start, openWindow: true, fullTrunk: true)

print(sportCar)
print(cargoCar)
